package com.example.dynamitemod;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.ProjectileItemEntity;
import net.minecraft.item.Item;
import net.minecraft.network.IPacket;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.EntityRayTraceResult;
import net.minecraft.world.Explosion;
import net.minecraft.world.World;
import net.minecraftforge.fml.network.NetworkHooks;

/**
 * Брошенная динамитная шашка. Взрывается, как только касается любого блока
 * (или сущности). Если никуда не попала - взрывается через 10 секунд.
 */
public class DynamiteEntity extends ProjectileItemEntity {

    /** Сила взрыва (TNT = 4.0, крипер = 3.0). */
    private static final float EXPLOSION_POWER = 3.0F;
    /** Максимальное время жизни в тиках (20 тиков = 1 секунда). */
    private static final int MAX_LIFETIME = 200;

    public DynamiteEntity(EntityType<? extends DynamiteEntity> type, World world) {
        super(type, world);
    }

    public DynamiteEntity(World world, LivingEntity thrower) {
        super(ModEntities.DYNAMITE.get(), thrower, world);
    }

    public DynamiteEntity(World world, double x, double y, double z) {
        super(ModEntities.DYNAMITE.get(), x, y, z, world);
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.DYNAMITE.get();
    }

    @Override
    public void tick() {
        super.tick();

        if (this.level.isClientSide) {
            // дымок и искры от фитиля
            this.level.addParticle(ParticleTypes.SMOKE, this.getX(), this.getY() + 0.25D, this.getZ(), 0.0D, 0.0D, 0.0D);
            this.level.addParticle(ParticleTypes.FLAME, this.getX(), this.getY() + 0.25D, this.getZ(), 0.0D, 0.0D, 0.0D);
        } else if (this.tickCount > MAX_LIFETIME) {
            this.explode();
        }
    }

    @Override
    protected void onHitBlock(BlockRayTraceResult result) {
        super.onHitBlock(result);
        this.explode();
    }

    @Override
    protected void onHitEntity(EntityRayTraceResult result) {
        super.onHitEntity(result);
        this.explode();
    }

    private void explode() {
        if (!this.level.isClientSide && this.isAlive()) {
            this.level.explode(this, this.getX(), this.getY(), this.getZ(), EXPLOSION_POWER, Explosion.Mode.BREAK);
            this.remove();
        }
    }

    @Override
    public IPacket<?> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
